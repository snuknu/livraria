package livraria.bean;

import java.util.List;

import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.validator.ValidatorException;

import livraria.dao.DAO;
import livraria.modelo.Autor;
import livraria.modelo.Livro;

@ManagedBean(name = "livroBean")
@ViewScoped
public class LivroBean {

	private Livro livro = new Livro();
	private Integer autorId;
	private Integer livroId;

	public Livro getLivro() {
		return livro;
	}

	public List<Autor> getAutores() {
		return new DAO<Autor>(Autor.class).listaTodos();
	}

	public List<Autor> getAutoresDoLivro() {
		return this.livro.getAutores();
	}

	public void gravarAutor() {
		Autor autor = new DAO<Autor>(Autor.class).buscaPorId(autorId);
		this.livro.adicionaAutor(autor);
	}

	public List<Livro> getLivros() {
		return new DAO<Livro>(Livro.class).listaTodos();
	}

	public void gravar() {
		System.out.println("Gravando livro " + this.livro.getTitulo());

		if (livro.getAutores().isEmpty()) {
			FacesContext.getCurrentInstance().addMessage("autor",
					new FacesMessage("Livro deve ter pelo menos um Autor."));
			return;
		}

		new DAO<Livro>(Livro.class).adiciona(this.livro);

		this.livro = new Livro();
	}

	public void alterar(Livro livro) {
		System.out.println("Alterando livro " + this.livro.getTitulo());
		if (livro == null) {
			FacesContext.getCurrentInstance().addMessage("livro", new FacesMessage("Livro não existe na base"));
			return;
		}
		new DAO<Livro>(Livro.class).atualiza(livro);
	}
	
	public void remover(Livro livro) {
		System.out.println("Removendo livro " + this.livro.getTitulo());
		if (livro == null) {
			FacesContext.getCurrentInstance().addMessage("livro", new FacesMessage("Livro não existe na base"));
			return;
		}
		new DAO<Livro>(Livro.class).remove(livro);
	}

	public Integer getAutorId() {
		return autorId;
	}

	public void setAutorId(Integer autorId) {
		this.autorId = autorId;
	}

	public Integer getLivroId() {
		return livroId;
	}

	public void setLivroId(Integer livroId) {
		this.livroId = livroId;
	}

	public String formAutor() {
		System.out.println("Chamando o formulário do Autor");
		return "autor?faces-redirect=true";
	}

	public void carregar(Integer idLivro) {
		System.out.println("Chamando o formulário do Livro");
		this.livro = new DAO<Livro>(Livro.class).buscaPorId(idLivro);

	}

	public void comecaComDigitoUm(FacesContext fc, UIComponent component, Object value) throws ValidatorException {
		String valor = value.toString();
		if (!valor.startsWith("1")) {
			throw new ValidatorException(new FacesMessage("Deveria começar com o dígito 1."));
		}
	}

}
